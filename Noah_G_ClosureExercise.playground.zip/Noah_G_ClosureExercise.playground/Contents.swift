import UIKit

let multiplication = {
    (number1: Int, number2: Int) -> Int in
    return number1 * number2
}
let multiple = multiplication(15, 203)
print (multiple)
